package com.xinwei.orderDb.Const;

public class UserOrderConst {
	public static final int RESULT_SUCCESS = 0;
	public static final int RESULT_FAILURE = 10100;
	// 10001 -- 10100
	public static final int RESULT_Error_startCode = 10001;
	public static final int RESULT_Error_NotFound = 10002;

}
